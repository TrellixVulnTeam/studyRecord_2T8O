# Hello world プログラム
print("Hello world.")