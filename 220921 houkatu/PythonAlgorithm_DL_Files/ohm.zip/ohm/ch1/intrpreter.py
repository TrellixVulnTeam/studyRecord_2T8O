x = 1 + 5
print("x の値 =", x)