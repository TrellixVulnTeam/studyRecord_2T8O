arr = [1, 2, 3, 4]
for i in range(0, len(arr)):
    new_val = arr[i] * 2
    new_val += 10
    arr[i] = new_val